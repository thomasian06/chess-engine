

#include <iostream>
#include "chessBoard.hpp"
#include <time.h>

long getTimeMs() {
    clock_t t;
    t = clock();
    return t;
}
